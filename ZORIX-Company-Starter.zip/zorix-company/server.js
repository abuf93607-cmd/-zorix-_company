require("dotenv").config();

const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const SQLiteStore = SQLiteStoreFactory(session);
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

const required = ["SESSION_SECRET", "BOT_API_SECRET"];
for (const key of required) {
  if (!process.env[key] || process.env[key].includes("CHANGE_THIS")) {
    console.error(`Missing or unsafe environment variable: ${key}`);
    process.exit(1);
  }
}
if (isProduction && (!process.env.BASE_URL || !process.env.BASE_URL.startsWith("https://"))) {
  console.error("In production, BASE_URL must use HTTPS.");
  process.exit(1);
}
if (isProduction) app.set("trust proxy", 1);

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "zorix.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price_sar INTEGER NOT NULL DEFAULT 0,
    category TEXT NOT NULL DEFAULT 'برمجيات',
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT NOT NULL,
    username TEXT NOT NULL,
    product_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(product_id) REFERENCES products(id)
  );
  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const productCount = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
if (!productCount) {
  const add = db.prepare("INSERT INTO products (name, description, price_sar, category) VALUES (?, ?, ?, ?)");
  add.run("بوت ديسكورد مخصص", "برمجة بوت حسب احتياجك ومواصفات مشروعك.", 150, "بوتات");
  add.run("تصميم واجهة متجر", "واجهة متجر رقمية عصرية قابلة للتخصيص.", 100, "تصاميم");
  add.run("نظام تراخيص", "إدارة مفاتيح التفعيل ومدة الاشتراك.", 200, "أنظمة");
}

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

app.use(session({
  name: "zorix.sid",
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const generalLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: "draft-7", legacyHeaders: false });
const orderLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 5, standardHeaders: "draft-7", legacyHeaders: false });
app.use(generalLimiter);

function isAdmin(req) {
  const admins = (process.env.ADMIN_DISCORD_IDS || "").split(",").map(x => x.trim()).filter(Boolean);
  return Boolean(req.session.user && admins.includes(req.session.user.id));
}
function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "سجل دخولك بحساب Discord أولاً." });
  next();
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(403).json({ error: "هذه الصفحة مخصصة للإدارة." });
  next();
}
function safeText(value, max = 300) {
  return String(value ?? "").trim().slice(0, max);
}
function log(actor, action) {
  db.prepare("INSERT INTO audit_logs (actor, action) VALUES (?, ?)").run(actor, action);
}
function constantTimeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function requireBot(req, res, next) {
  const provided = req.get("x-zorix-bot-secret");
  if (!constantTimeEqual(provided, process.env.BOT_API_SECRET)) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

app.get("/api/config", (req, res) => {
  res.json({
    brand: "ZORIX Company",
    inviteUrl: process.env.DISCORD_INVITE_URL || "",
    discordConfigured: Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET)
  });
});
app.get("/api/me", (req, res) => {
  res.json({ user: req.session.user || null, admin: isAdmin(req) });
});
app.get("/api/products", (req, res) => {
  const products = db.prepare("SELECT id, name, description, price_sar, category FROM products WHERE active = 1 ORDER BY id DESC").all();
  res.json({ products });
});
app.get("/api/my-orders", requireLogin, (req, res) => {
  const orders = db.prepare(`
    SELECT o.id, o.status, o.note, o.created_at, p.name AS product_name, p.price_sar
    FROM orders o JOIN products p ON p.id = o.product_id
    WHERE o.discord_id = ? ORDER BY o.id DESC LIMIT 50
  `).all(req.session.user.id);
  res.json({ orders });
});
app.post("/api/orders", requireLogin, orderLimiter, (req, res) => {
  const productId = Number(req.body.productId);
  if (!Number.isSafeInteger(productId) || productId < 1) return res.status(400).json({ error: "المنتج غير صحيح." });
  const product = db.prepare("SELECT id FROM products WHERE id = ? AND active = 1").get(productId);
  if (!product) return res.status(404).json({ error: "المنتج غير موجود." });
  const result = db.prepare("INSERT INTO orders (discord_id, username, product_id) VALUES (?, ?, ?)")
    .run(req.session.user.id, safeText(req.session.user.username, 80), productId);
  log(req.session.user.id, `Created order #${result.lastInsertRowid}`);
  res.status(201).json({ ok: true, orderId: result.lastInsertRowid, message: "تم إنشاء الطلب. سيتم التواصل معك لتأكيد الدفع." });
});

/* Discord OAuth2 */
app.get("/auth/discord", authLimiter, (req, res) => {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_CLIENT_SECRET || !process.env.DISCORD_CALLBACK_URL) {
    return res.status(503).send("Discord OAuth غير مضبوط بعد. راجع ملف README.");
  }
  const state = crypto.randomBytes(24).toString("hex");
  req.session.oauthState = state;
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_CALLBACK_URL,
    response_type: "code",
    scope: "identify",
    state
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});
app.get("/auth/discord/callback", authLimiter, async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!code || !state || !req.session.oauthState || !constantTimeEqual(state, req.session.oauthState)) {
      return res.status(400).send("تعذر التحقق من تسجيل الدخول. حاول مرة أخرى.");
    }
    delete req.session.oauthState;
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code: String(code),
        redirect_uri: process.env.DISCORD_CALLBACK_URL
      })
    });
    if (!tokenResponse.ok) throw new Error("Discord token exchange failed");
    const tokenData = await tokenResponse.json();
    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    if (!userResponse.ok) throw new Error("Discord user lookup failed");
    const user = await userResponse.json();
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.user = { id: user.id, username: user.global_name || user.username, avatar: user.avatar || null };
    req.session.save(err => {
      if (err) return res.status(500).send("تعذر حفظ الجلسة.");
      res.redirect("/");
    });
  } catch (error) {
    console.error("Discord OAuth error:", error.message);
    res.status(502).send("تعذر تسجيل الدخول عبر Discord. حاول لاحقاً.");
  }
});
app.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("zorix.sid", { httpOnly: true, secure: isProduction, sameSite: "lax" });
    res.json({ ok: true });
  });
});

/* Admin API */
app.get("/api/admin/orders", requireLogin, requireAdmin, (req, res) => {
  const orders = db.prepare(`
    SELECT o.id, o.username, o.discord_id, o.status, o.note, o.created_at, p.name AS product_name
    FROM orders o JOIN products p ON p.id = o.product_id ORDER BY o.id DESC LIMIT 100
  `).all();
  res.json({ orders });
});
app.post("/api/admin/products", requireLogin, requireAdmin, (req, res) => {
  const name = safeText(req.body.name, 100);
  const description = safeText(req.body.description, 500);
  const category = safeText(req.body.category, 50) || "برمجيات";
  const price = Number(req.body.price);
  if (!name || !Number.isSafeInteger(price) || price < 0 || price > 10000000) {
    return res.status(400).json({ error: "تحقق من اسم المنتج والسعر." });
  }
  const result = db.prepare("INSERT INTO products (name, description, price_sar, category) VALUES (?, ?, ?, ?)")
    .run(name, description, price, category);
  log(req.session.user.id, `Added product #${result.lastInsertRowid}`);
  res.status(201).json({ ok: true, id: result.lastInsertRowid });
});
app.patch("/api/admin/orders/:id", requireLogin, requireAdmin, (req, res) => {
  const status = safeText(req.body.status, 20);
  const allowed = ["pending", "processing", "completed", "cancelled"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "حالة الطلب غير صحيحة." });
  const result = db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "الطلب غير موجود." });
  log(req.session.user.id, `Changed order #${req.params.id} to ${status}`);
  res.json({ ok: true });
});

/* Bot-to-site API: keep BOT_API_SECRET only in the bot's server environment. */
app.get("/api/bot/orders/:id", requireBot, (req, res) => {
  const order = db.prepare(`
    SELECT o.id, o.discord_id, o.username, o.status, o.note, p.name AS product_name, p.price_sar
    FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = ?
  `).get(Number(req.params.id));
  if (!order) return res.status(404).json({ error: "Order not found" });
  res.json({ order });
});
app.post("/api/bot/orders/:id/status", requireBot, (req, res) => {
  const status = safeText(req.body.status, 20);
  const allowed = ["pending", "processing", "completed", "cancelled"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status" });
  const result = db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Order not found" });
  log("discord-bot", `Changed order #${req.params.id} to ${status}`);
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, "public", "404.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ZORIX website running on port ${PORT}`);
});

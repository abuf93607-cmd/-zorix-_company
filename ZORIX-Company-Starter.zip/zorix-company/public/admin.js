const $ = s => document.querySelector(s);
async function api(url, options = {}) {
  const res = await fetch(url, { credentials: "same-origin", ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "حدث خطأ");
  return data;
}
const labels = {pending:"بانتظار التأكيد",processing:"قيد التجهيز",completed:"مكتمل",cancelled:"ملغي"};
async function loadOrders() {
  const { orders } = await api("/api/admin/orders");
  const host = $("#adminOrders"); host.innerHTML = "";
  if (!orders.length) { host.textContent = "لا توجد طلبات."; return; }
  orders.forEach(o => {
    const row = document.createElement("div"); row.className = "admin-order";
    const info = document.createElement("div"); const title = document.createElement("strong"); title.textContent = `#${o.id} — ${o.product_name}`;
    const sub = document.createElement("small"); sub.textContent = `${o.username} · Discord ID: ${o.discord_id}`;
    info.append(title, sub);
    const select = document.createElement("select");
    Object.entries(labels).forEach(([value, label]) => { const option = document.createElement("option"); option.value = value; option.textContent = label; option.selected = value === o.status; select.append(option); });
    select.addEventListener("change", async () => { try { await api(`/api/admin/orders/${o.id}`, { method: "PATCH", body: JSON.stringify({status:select.value}) }); $("#adminMessage").textContent = "تم تحديث الطلب."; } catch(e) { $("#adminMessage").textContent = e.message; } });
    row.append(info, select); host.append(row);
  });
}
$("#productForm").addEventListener("submit", async e => {
  e.preventDefault(); const f = new FormData(e.currentTarget);
  try { await api("/api/admin/products", { method:"POST", body:JSON.stringify({name:f.get("name"),price:Number(f.get("price")),category:f.get("category"),description:f.get("description")}) }); e.currentTarget.reset(); $("#adminMessage").textContent = "تمت إضافة المنتج."; }
  catch(err) { $("#adminMessage").textContent = err.message; }
});
(async () => { try { await loadOrders(); } catch(e) { $("#adminOrders").textContent = e.message + " — تأكد أنك سجلت الدخول بحساب إداري."; } })();
const $ = (s) => document.querySelector(s);
const toast = (message) => { const el = $("#toast"); el.textContent = message; el.classList.add("show"); setTimeout(() => el.classList.remove("show"), 3200); };
const money = (n) => `${Number(n).toLocaleString("ar-SA")} ر.س`;
async function api(url, options = {}) {
  const res = await fetch(url, { credentials: "same-origin", ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "حدث خطأ. حاول مرة أخرى.");
  return data;
}
function statusName(status) { return ({pending:"بانتظار التأكيد",processing:"قيد التجهيز",completed:"مكتمل",cancelled:"ملغي"})[status] || status; }
async function loadMe() {
  const data = await api("/api/me");
  if (data.user) {
    $("#userLabel").textContent = data.user.username;
    $("#loginBtn").classList.add("hidden");
    $("#logoutBtn").classList.remove("hidden");
    if (data.admin) {
      const link = document.createElement("a"); link.href = "/admin.html"; link.className = "btn btn-outline"; link.textContent = "الإدارة"; $(".auth-area").append(link);
    }
  } else {
    $("#userLabel").textContent = "زائر";
    $("#loginBtn").classList.remove("hidden");
    $("#logoutBtn").classList.add("hidden");
  }
  return data;
}
async function loadProducts() {
  const { products } = await api("/api/products");
  const host = $("#products");
  if (!products.length) { host.textContent = "لا توجد منتجات حالياً."; return; }
  host.innerHTML = "";
  products.forEach(p => {
    const card = document.createElement("article"); card.className = "product-card";
    const tag = document.createElement("div"); tag.className = "product-tag"; tag.textContent = p.category;
    const title = document.createElement("h3"); title.textContent = p.name;
    const desc = document.createElement("p"); desc.textContent = p.description;
    const foot = document.createElement("div"); foot.className = "product-foot";
    const price = document.createElement("strong"); price.textContent = money(p.price_sar);
    const button = document.createElement("button"); button.className = "btn btn-primary"; button.textContent = "اطلب الآن";
    button.addEventListener("click", async () => {
      try { await api("/api/orders", { method: "POST", body: JSON.stringify({ productId: p.id }) }); toast("تم إنشاء طلبك. الدفع والتسليم يتم تأكيدهما مع الإدارة حالياً."); await loadOrders(); }
      catch (e) { if (e.message.includes("سجل دخولك")) location.href = "/auth/discord"; else toast(e.message); }
    });
    foot.append(price, button); card.append(tag, title, desc, foot); host.append(card);
  });
}
async function loadOrders() {
  const host = $("#myOrders");
  try {
    const { orders } = await api("/api/my-orders");
    if (!orders.length) { host.textContent = "ما عندك طلبات حالياً."; return; }
    host.innerHTML = "";
    orders.forEach(o => {
      const row = document.createElement("div"); row.className = "order-row";
      const name = document.createElement("strong"); name.textContent = `#${o.id} — ${o.product_name}`;
      const status = document.createElement("span"); status.className = `status status-${o.status}`; status.textContent = statusName(o.status);
      row.append(name, status); host.append(row);
    });
  } catch { host.textContent = "سجّل دخولك بحساب Discord لعرض طلباتك."; }
}
$("#logoutBtn").addEventListener("click", async () => { await api("/auth/logout", { method: "POST", body: "{}" }); location.reload(); });
(async () => {
  $("#year").textContent = new Date().getFullYear();
  try { const cfg = await api("/api/config"); if (cfg.inviteUrl) $("#inviteLink").href = cfg.inviteUrl; await loadMe(); await loadOrders(); await loadProducts(); }
  catch (e) { toast(e.message); }
})();